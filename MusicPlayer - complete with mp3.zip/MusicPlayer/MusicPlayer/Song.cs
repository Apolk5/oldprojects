﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WMPLib;

namespace MusicPlayer
{
    class Song
    {
        //what info do I care about
        private int id;
        private string title;
        private WindowsMediaPlayer player;



        //what actions should I perform

        //custom constructor
        public Song(int newId, string newTitle)
        {
            SetId(newId);
            SetTitle(newTitle);
            player = new WindowsMediaPlayer();
        }

        public int GetId()
        {
            return id;
        }

        private void SetId(int newId)
        {
            //do things like check to make sure
            //it's a valid value.  Check for
            //duplicates.  Etc.
            id = newId;
        }

        public string GetTitle()
        {
            return title;
        }

        private void SetTitle(string newTitle)
        {
            title = newTitle;
        }

        public void Play()
        {
            //Console.WriteLine("I'm currently playing " + title);
            player.URL = title;
            player.controls.play();
        }

        public void Stop()
        {
            player.controls.stop();
        }
    }
}
