﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu view = new Menu();
            MusicPlayer model = new MusicPlayer();
            int userSelection;
            do
            {
                userSelection = view.DisplayMenu();
                if (userSelection == 1)
                {
                    //view songs
                    //Song[] songs = model.GetSongs();
                    //view.ShowSongs(songs);
                    view.ShowSongs(model.GetSongs());
                }
                else if (userSelection == 2)
                {
                    //add a song
                    model.AddSong(view.AddSong());
                }
                else if (userSelection == 3)
                {
                    //remove a song
                    view.ShowSongs(model.GetSongs());
                    model.RemoveSong(view.RemoveSong());
                }
                else if (userSelection == 4)
                {
                    //play a song
                    view.ShowSongs(model.GetSongs());
                    model.PlaySong(view.PlaySong());
                }
                else if (userSelection == 5)
                {
                    //stop playback
                    model.StopPlayback();
                }

            }
            while (userSelection != 6);
        }
    }
}
