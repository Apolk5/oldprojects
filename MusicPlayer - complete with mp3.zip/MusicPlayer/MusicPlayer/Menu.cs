﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    class Menu
    {
        //what info do I care about?
        //not a whole lot...  THIS IS THE VIEW!

        //what actions do I care about?
        public int DisplayMenu()
        {
            Console.WriteLine("_____________Menu____________");
            Console.WriteLine("1) View Songs");
            Console.WriteLine("2) Add a Song");
            Console.WriteLine("3) Remove a Song");
            Console.WriteLine("4) Play a Song");
            Console.WriteLine("5) Stop playback");
            Console.WriteLine("6) Exit");
            Console.WriteLine("______________________________");
            Console.WriteLine("Make a selection (1-6):");
            return Convert.ToInt32(Console.ReadLine());
        }

        public void ShowSongs(Song[] songs)
        {
            Console.WriteLine("______________Songs____________");
            foreach (Song s in songs)
            {
                Console.WriteLine(s.GetId() + ") " + s.GetTitle());
            }
            Console.WriteLine("________________________________");
        }

        public Song AddSong()
        {
            Console.WriteLine("What is the ID of this song?");
            int newId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("What is the title of this song?");
            string newTitle = Console.ReadLine();

            Song newSong = new Song(newId, newTitle);
            return newSong;
        }

        public int RemoveSong()
        {
            Console.WriteLine("What is the ID of the song to be removed?");
            return Convert.ToInt32(Console.ReadLine());
        }

        public int PlaySong()
        {
            Console.WriteLine("What is the ID of the song you want to play?");
            return Convert.ToInt32(Console.ReadLine());
        }
    }
}
