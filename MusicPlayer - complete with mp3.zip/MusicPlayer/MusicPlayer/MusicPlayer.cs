﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    class MusicPlayer
    {
        //what info do I care about?
        //I care about a collection of song instances
        //check out the List object
        private List<Song> library;

        //what actions do I care about?

        public MusicPlayer()
        {
            library = new List<Song>();
        }

        // 1) if you hand me a song, I should store it
        //in my collection
        public void AddSong(Song s)
        {
            library.Add(s);
        }
        //2) if you tell me which song to delete, I should
        //go ahead and delete that song for you
        public void RemoveSong(int id)
        {
            //Song toBeRemoved = library.Find(x => x.GetId() == id);
            //library.Remove(toBeRemoved);
            library.Remove(library.Find(potato => potato.GetId() == id));
        }
        //3) if you ask me, I should give you a simple list
        //of all the songs I'm holding on to

        public Song[] GetSongs()
        {
            return library.ToArray();
        }

        public void PlaySong(int songId)
        {
            //Song songToPlay = library.Find(hat => hat.GetId() == songId);
            //songToPlay.Play();
            library.Find(monkey => monkey.GetId() == songId).Play();
        }

        public void StopPlayback()
        {
            foreach (Song s in library)
            {
                s.Stop();
            }
        }
    }
}
